package Cadastroaluno.models

data class Aluno(
    val nomeAluno:String,
    val registroAluno: Int?
)
